function main
clc; clear; closereq;
%resets streak and reads saved wallet value
streak = 0;
CWal = table2array(readtable("coins.txt"));
coins = CWal(1, 1);
if coins <= 0
    %resets wallet to 9 if empty
    coins = 9;
    fprintf('Coin Loan! Coins set to %i', coins)
end
%starts game
game

function game
closereq;
gamecount = 1; %tracks if game will loop

%sets initial bet and cards
coins = coins - 1;
bet = 1;
drawstate = [0, 0, 0, 0, 0];
redraw = 0;

%sets up UI
fireflower = uifigure;
i1 = 'cloud.png'; i2 = 'mushroom.png'; i3 = 'flower.png';
i4 = 'luigi.png'; i5 = 'mario.png'; i6 = 'star.png';
gr = 'Green_rectangle.png'; rr = 'Red_rectangle.png';
gr1 = uiimage(fireflower, "ImageSource",rr,"Position",[60 150 80 20], 'Visible','on');
gr2 = uiimage(fireflower, "ImageSource",rr,"Position",[160 150 80 20], 'Visible','on');
gr3 = uiimage(fireflower, "ImageSource",rr,"Position",[260 150 80 20], 'Visible','on');
gr4 = uiimage(fireflower, "ImageSource",rr,"Position",[360 150 80 20], 'Visible','on');
gr5 = uiimage(fireflower, "ImageSource",rr,"Position",[460 150 80 20], 'Visible','on');
stopname = 'Stop After';
stopbutton = uibutton(fireflower, ...
    "Text",stopname, ...
    "Position",[450 200 99 99], "ButtonPushedFcn", @(src,event) ButtonPushed(9));
i = uilabel(fireflower, 'Text', '9', 'Position', [450 300 100 100]);
j = uilabel(fireflower, 'Text', '1', 'Position', [120 300 100 100]);
f = uibutton(fireflower, ...
    "Text","Redraw", ...
    "Position",[250 200 50 50], "ButtonPushedFcn", @(src,event) ButtonPushed(6));
g = uibutton(fireflower, ...
    "Text","Bet +", ...
    "Position",[50 350 50 50], "ButtonPushedFcn", @(src,event) ButtonPushed(7));
h = uibutton(fireflower, ...
    "Text","Bet -", ...
    "Position",[50 300 50 50], "ButtonPushedFcn", @(src,event) ButtonPushed(8));
imshow('poker.png')
moneycounters

%deals out cards
dealerset = [randi([1, 6]), randi([1, 6]), randi([1, 6]), randi([1, 6]), randi([1, 6])];
cardset = [0 0 0 0 0];
card(1); card(2); card(3); card(4); card(5);

%ui button reactions
function ButtonPushed(x)
switch x
%card 1
case 1
    if redraw == 0
        if drawstate(1) == 0
            drawstate(1) = 1;
            gr1 = uiimage(fireflower, "ImageSource",gr,"Position",[60 150 80 20], 'Visible','on');
        else
            drawstate(1) = 0;
            gr1 = uiimage(fireflower, "ImageSource",rr,"Position",[60 150 80 20], 'Visible','on');
        end
    end
    return
%card 2
case 2
    if redraw == 0
        if drawstate(2) == 0
            drawstate(2) = 1;
            gr2 = uiimage(fireflower, "ImageSource",gr,"Position",[160 150 80 20], 'Visible','on');
        else
            drawstate(2) = 0;
            gr2 = uiimage(fireflower, "ImageSource",rr,"Position",[160 150 80 20], 'Visible','on');
        end
    end
    return
%card 3
case 3
    if redraw == 0
        if drawstate(3) == 0
            drawstate(3) = 1;
            gr3 = uiimage(fireflower, "ImageSource",gr,"Position",[260 150 80 20], 'Visible','on');
        else
            drawstate(3) = 0;
            gr3 = uiimage(fireflower, "ImageSource",rr,"Position",[260 150 80 20], 'Visible','on');
        end
    end
    return
%card 4
case 4
    if redraw == 0
    if drawstate(4) == 0
            drawstate(4) = 1;
            gr4 = uiimage(fireflower, "ImageSource",gr,"Position",[360 150 80 20], 'Visible','on');
        else
            drawstate(4) = 0;
            gr4 = uiimage(fireflower, "ImageSource",rr,"Position",[360 150 80 20], 'Visible','on');
        end
    end
    return
%card 5
case 5
    if redraw == 0
        if drawstate(5) == 0
            drawstate(5) = 1;
            gr5 = uiimage(fireflower, "ImageSource",gr,"Position",[460 150 80 20], 'Visible','on');
        else
            drawstate(5) = 0;
            gr5 = uiimage(fireflower, "ImageSource",rr,"Position",[460 150 80 20], 'Visible','on');
        end
    end
    return
%redraw / continue gaem
case 6
    %redraws selected cards
    if redraw == 0
        redraw = 1;
        if drawstate(1) == 1
            card(1);
        end
        if drawstate(2) == 1
            card(2);
        end
        if drawstate(3) == 1
            card(3);
        end
        if drawstate(4) == 1
            card(4);
        end
        if drawstate(5) == 1
            card(5); 
        end
        imshow('poker.png')
        pause(2);
        %compares card values and scores
        cardcompare(cardset, dealerset)
        %checks if user can or wants to continue
        if gamecount == 1
          if coins > 0
               game;
           else
                fprintf('Nah you broke mf lmao\n');
           end
           else
                clear; closereq;
           end
        end
    return
case 7
    %increase bet
    if redraw == 0
    if bet < 5 && coins > 0
        bet = bet + 1;
        coins = coins - 1;
        moneycounters;
        return
    end
    end
case 8
    %decreases bet
    if redraw == 0
    if bet > 1
        bet = bet - 1;
        coins = coins + 1;
        moneycounters;
        return
    end
    end
case 9
    %opt to stop
    gamecount = 2;
end
end

function moneycounters
    delete(i);
    delete(j);
    temp1 = num2str(coins);
    temp2 = num2str(bet);
    i = uilabel(fireflower, 'Text', temp1, 'Position', [450 300 100 100]);
    j = uilabel(fireflower, 'Text', temp2, 'Position', [120 300 100 100]);
end;

function card = card(i)
    ia = randi([1, 6]);
    cardset(i) = ia;
    pi = [(-50 + 100*i) 50 99 99];
    switch ia
        case 1
            ci = i1;
        case 2
            ci = i2;
        case 3
            ci = i3;
        case 4
            ci = i4;
        case 5
            ci = i5;
        case 6
            ci = i5;
    end
    a = uibutton(fireflower, ...
    "Text","Select", ...
    "Icon",ci, ...
    "IconAlignment","top", ...
    "Position",pi, "ButtonPushedFcn", @(src,event) ButtonPushed(i));
end

    function cardcompare(x, y)
        playerscore = 0;
        dealerscore = 0;
        playhand = sort(x);
        dealhand = sort(y);
        if playhand(1) == playhand(5)
            playerscore = 16;
        elseif playhand(2) == playhand(5)
            playerscore = 8;
        elseif (playhand(1) == playhand(2) && playhand(3) == playhand(5)) || (playhand(1) == playhand(3) && playhand(4) == playhand(5))
            playerscore = 6;
        elseif playhand(3) == playhand(5)
            playerscore = 4;
        elseif playhand(4) == playhand(5)
            playerscore = 2;
        else
            playerscore = 0;
        end

        if dealhand(1) == dealhand(5)
            dealerscore = 16;
        elseif dealhand(2) == dealhand(5)
            dealerscore = 8;
        elseif (dealhand(1) == dealhand(2) && dealhand(3) == dealhand(5)) || (dealhand(1) == dealhand(3) && dealhand(4) == dealhand(5))
            dealerscore = 6;
        elseif dealhand(3) == dealhand(5)
            dealerscore = 4;
        elseif dealhand(4) == dealhand(5)
            dealerscore = 2;
        else
            dealerscore = 0;
        end

        if playerscore < 3
          if playhand(1) == playhand(2)
            if playhand(3) == playhand(4)
                playerscore = 3;
            elseif playhand(3) == playhand(5)
                playerscore = 3;
            elseif playhand(4) == playhand(5)
                playerscore = 3;
            end
            elseif playhand(2) == playhand(3)
                if playhand(4) == playhand(5)
                    playerscore = 3;
                end
            end
        end

        if dealerscore < 3
            if dealhand(1) == dealhand(2)
                if dealhand(3) == dealhand(4)
                    dealerscore = 3;
                elseif dealhand(3) == dealhand(5)
                    dealerscore = 3;
                elseif dealhand(4) == dealhand(5)
                    dealerscore = 3;
                end
            elseif dealhand(2) == dealhand(3)
                if dealhand(4) == dealhand(5)
                    dealerscore = 3;
                end
            end
        end
    if dealerscore < playerscore
         streak = streak + 1;
         coins = coins + (round(((playerscore - dealerscore)*bet)/4.3) + 1)*(round(streak/5) + 1);
         fprintf('Player Wins\nStar Streak at %i\n\n', streak)
    elseif dealerscore > playerscore
        streak = streak - 5;
        if streak < 0
            streak = 0;
        end
        fprintf('Luigi Wins\nStar Streak at %i\n\n', streak)
    else
        if dealhand(5) < playhand(5)
            streak = streak + 1;
            coins = coins + (round(((playerscore - dealerscore)*bet)/4.3) + 1)*(round(streak/5) + 1);
            fprintf('Player Wins\nStar Streak at %i\n\n', streak)


        else
            streak = streak - 5;
            if streak < 0
                streak = 0;
            end
            fprintf('Luigi Wins\nStar Streak at %i\n\n', streak)

        end
    end
    T = table(coins);
    writetable(T, "coins.txt")
    end
end
end